module.exports = {
  // Socket链接 暂不做配置
  WSS_SERVER_URL:'',
  // Socket调试模式
  SERVER_DEBUG:true,
  // 心跳间隔
  PINGINTERVAL:3000
}