<template>
	<view class="content">
		<ylh-navbar :title="title"></ylh-navbar>

		<u-form class="add_form">
			<u-form-item   label="类型" label-width="150">
				{{typeMap[data.type]}}
			</u-form-item>			
			
			<u-form-item label-width="130" label="标题">
				<u-input type="text" v-model="data.title" />
			</u-form-item>

			<u-form-item label-width="130" label="描述">
				<u-input type="textarea" v-model="data.content" />
			</u-form-item>

			<u-button class="bottom-button" type="primary" size="default" @click="submit">修改</u-button>
		</u-form>

		<ylh-tabbar></ylh-tabbar>
	</view>
</template>

<script>

	export default {
		data() {
			return {
				title: "修改测试",
				typeMap: ['','图片','音频','视频'],
				data: {
					type: 0,
					title: '',
					content: '',
				},
			}
		},
		
		onLoad(options) {
			this.getData(options.id);
		},
		methods: {
			getData(id){
				this.$u.api.getTest({id:id}).then(res => {
						if(res  && res.ret) {
							this.data=res.data;
						}
				})				
			},
			submit() {
				this.$u.api.updateTest(this.data).then(res => {
					if (res && res.ret) {					
						uni.showModal({
							title:"消息",
							content: "修改成功",
							showCancel:false,
							success(res){
								uni.navigateBack()
							}
						})
					}
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.add_form {
		padding: 0rpx 30rpx;
		width: 100%;
	}

	.custom-style {
		margin-left: unset;
	}


	/*    .u-form-item--left{ 
		flex:0 0 140rpx !important; 
	}*/
	
	.bangzhu{
		position: fixed;
		_position:absolute;
		right: 5px;
		bottom: 120px;
		word-break:break-all;
	}	
	.bottom-button {
		margin-top: 20rpx;
		margin-bottom: 20rpx;
	}
</style>
