<template>
	<view>
		<ylh-navbar :title="title"></ylh-navbar>
		
			<u-cell-group v-for="(item, index) in items" :key="index" :class="[index>0?'u-m-t-20':'']">
				<u-cell-item label-width="130" label="名称" :arrow="false">
					{{item.name}}
				</u-cell-item>
				
				<u-cell-item label-width="130" label="路径" :arrow="false" >
					{{item.path}}
				</u-cell-item>
				
				<u-cell-item label-width="130" label="预览" :arrow="false" >
					<u-image v-if="test.type==1" width="100%" height="300rpx" :src="item.path"></u-image>						
						<audio v-if="test.type==2" :src="item.path"  controls />
						<video v-if="test.type==3" :src="item.path" controls />
				</u-cell-item>

				<u-form-item :label-position="labelPosition" v-for="(category, index2) in categorys" :key="index2" :label="category.value" label-width="150">
					<u-radio-group v-model="scoreMap.get(item.id).get(category.id).rid" @change="radioGroupChange(item.id,category.id,$event)" :width="radioCheckWidth" :wrap="radioCheckWrap">
						<u-radio shape="circle" v-for="(rank, index3) in ranks" :key="index3" :name="rank.id">{{ rank.value }}</u-radio>
					</u-radio-group>
				</u-form-item>			
			</u-cell-group>

			<u-button v-if="items.length>0" type="primary" size="default" @click="submit">提交</u-button>
			
		<ylh-tabbar></ylh-tabbar>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: "测试详情",
				uid:0,
				tid:0,		
				test:{},
				items: [],
				categorys:[],
				ranks:[],
				scores:[],
				scoreMap:{},
				radioCheckWidth: 'auto',
				radioCheckWrap: false,
				labelPosition: 'left',								
			}
		},
		onLoad(options) {
			this.uid = uni.getStorageSync('userID');
			if(!this.uid){
				uni.navigateTo({
				url: '/pages/login/index'
				})
			}
			
			this.tid=parseInt(options.pid);
			this.getTest(options.pid);
			this.getItem(options.pid);
		},
		methods: {
			getTest(id){
				this.$u.api.getTest({id:id}).then(res => {
							if(res  && res.ret) {
								this.test=res.data;
							}
					})								
			},			
			getItem(pid) {
				this.$u.api.getItemList({
					pid: pid
				}).then(ret => {
					this.items = ret;
					this.getCategory();					
				})
			},
			getCategory() {
				this.$u.api.getCategoryList({					
				}).then(ret => {
					this.categorys = ret;
					this.prepareScore();	
					this.getScore();								
					this.getRank();
				})
			},
			prepareScore(){
				let scoreMap = new Map();
				for(let item of this.items){
					for(let category of this.categorys){
						if(!scoreMap.has(item.id)) {
							scoreMap.set(item.id,new Map());
						}
						let s2=scoreMap.get(item.id);
						if(!s2.has(category.id)) {
							s2.set(category.id,{rid:0});
						}else{
							console.log("键值冲突");
						}
					}
				}
				//console.log(scoreMap);
				this.scoreMap = scoreMap;
			},
			getRank() {
				this.$u.api.getRankList({				
				}).then(ret => {
					this.ranks = ret;
				})
			},	
			getScore(uid,tid) {
				this.$u.api.getScoreList({
					uid: this.uid, tid: this.tid
				}).then(ret => {
					//console.log(ret);
					this.scores = ret;
					let scoreMap = this.scoreMap;
					for(let s of ret){
						if(!scoreMap.has(s.iid)) {
							//scoreMap.set(s.iid,new Map());
							console.log('键不存在');
							contiue;
						}
						let s2=scoreMap.get(s.iid);
						s2.set(s.cid,s);
					}
					//console.log(scoreMap);
					//this.scoreMap = scoreMap;
				})
			},
			radioGroupChange(iid,cid,e) {
				//console.log(this.tid,iid,cid,e);
				let ret=this.scores.filter(function(score){
					return score.iid==iid && score.cid==cid;
				});
				//console.log(ret);
				switch(ret.length){
					case 1:						
						let score = ret[0];
						score.rid = e;
						break;
					case 0:
						this.scores.push({id:0,uid:this.uid,tid:this.tid,iid:iid,cid:cid,rid:e,deleted:0});
						break;
					default:
						alert('发现重复项，请检查');
						break;
				}
			},
			submit(){
				if(this.scores.length!=this.items.length*this.categorys.length){
					uni.showToast({
						title:"还有漏项，请填完整！",
						icon:"error"
					});
					return;
				}
				this.$u.api.saveScores({
				scores:JSON.stringify(this.scores)}).then(ret => {
					if(ret.ret){
						uni.showModal({
							title:"保存成功！",
							success:function(){
								uni.redirectTo({
									url:'/pages/test/index'
								})								
							},
							showCancel:false
						})
					}else{
						uni.showToast({
							title:ret.message,
							icon:"error"
						})
					}
				})
			}
			
		}
	}
</script>

<style lang="scss">
	page {
		background-color: #ededed;
	}

	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	
</style>
