<template>
	<view class="content">
		<ylh-navbar :title="title"></ylh-navbar>

		<view>感谢您来参加音视频编码质量测试。<br />
测试分为三部分：图像、语音、视频。<br />
第一个为原图、原声，或原始视频，<br />
第二个往后是处理成不同格式的。<br />
质量指标有五个：<br />
高清相似度，流畅度，清晰度，细节丰富度，总体感觉。<br />
采用五级评分制：<br />
1很差，2较差，3一般，4较好，5很好。<br />
从上往下逐个观看（收听）打分完后，点击提交即可。<br /></view>
		
		<ylh-tabbar></ylh-tabbar>
	</view>
</template>

<script>
	export default {
		data() {
			return {

				title: "IPv6",
			}
		},
		onShow() {
			this.checkToken();
		},
		methods: {		
			
			checkToken(){
				// console.log('onShow');
				this.$u.api.checkToken().then(res => {
					if (res.ret) {
						this.user = res.user;
					}else{
						uni.showModal({
							title: "需要登录",
							content: res.message,
							showCancel:false,
							success(res) {
								if (res.confirm) {
									uni.navigateTo({
										url: '/pages/login/index'
									})
								}
							}
						});
						
					}
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	page {
		background-color: #ededed;
	}

	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		//padding: 40rpx;
	}

	
</style>
