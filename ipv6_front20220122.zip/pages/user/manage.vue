<template>
	<view class="content">
		<ylh-navbar :title="title"></ylh-navbar>

		<view class="uni-container">
			<uni-table ref="table" :loading="loading" border  emptyText="暂无更多数据"
				>
				<uni-tr>
					<uni-th align="center">ID</uni-th>
					<uni-th align="center">类型</uni-th>
					<uni-th align="center">用户名</uni-th>
					<uni-th align="center">操作</uni-th>
				</uni-tr>
				<uni-tr v-for="(item, index) in tableData" :key="index">
					<uni-td align="center">{{ item.id }}</uni-td>
					<uni-td align="center">{{ typeMap[item.type] }}</uni-td>
					<uni-td align="center">{{ item.name }}</uni-td>
					<uni-td>
							<view class="uni-group">
								<button class="uni-button" size="mini" type="primary"
									@click="gotoEdit(item.id)">修改</button>
							</view>
					</uni-td>
				</uni-tr>
			</uni-table>
		</view>
		<ylh-tabbar></ylh-tabbar>
	</view>
</template>

<script>

	export default {
		data() {
			return {
				title: '用户管理',
				loading: false,
				typeMap:[0,'管理员','普通用户'],
				tableData: [],
				
			}
		},
		onLoad() {
		},
		onShow()
		{
			this.getData()
		},
		methods: {
			// 获取数据
			getData() {
				this.loading = true
				this.$u.api.getUserList().then(res => {
					this.tableData = res;
					this.loading = false
				}).catch(res => {
					uni.showToast({
						title: res.message,
						icon: "none"
					});
				})
			},

			gotoEdit(id) {
				uni.navigateTo({
					url:'/pages/user/edit?id='+id
				})
			},			

		}
	}
</script>




<style>
	/* #ifndef H5 */
	page {
		padding-top: 85px;
	}

	/* #endif */
	.uni-group {
		display: flex;
		align-items: center;
		margin: 0 auto;
	}

	.yellow {
		background: #ee8a12;
	}

	.green {
		background: #27b08a;
		color: white;
	}

	.red {
		/* 		background: #fc0107; */
		color: #fc0107;
	}

	.in-line {
		width: 50%;
		display:
			inline-block;
		vertical-align: middle;
	}

	.flat {
		display: flex;
		flex-direction: row;
		align-items: center;
		justify-content: space-around;
	}
	
	.uni-input {
		border-width: 1rpx;
		border-style: solid;
		border-color: #dfdfdf;
	
		display: flex;
		/* width: 250rpx; */
		/* height: fit-content; */
		padding: 2px 2px;
		border-radius: 5px;
		/* align-items: center; */
		/* font-size: 20px; */
	}
</style>
