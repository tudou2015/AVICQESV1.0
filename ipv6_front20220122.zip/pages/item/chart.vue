<template>
	<view>
		<ylh-navbar :title="title"></ylh-navbar>
		
			<u-cell-group v-for="(item, index) in items" :key="index" :class="[index>0?'u-m-t-20':'']">
				<u-cell-item label-width="130" label="name" :arrow="false">
					{{item.name}}
				</u-cell-item>

				<u-cell-item label-width="130" label="路径" :arrow="false" >
					{{item.path}}
				</u-cell-item>
				
				<u-cell-item label-width="130" label="预览" :arrow="false" >
					<u-image v-if="test.type==1" width="100%" height="300rpx" :src="item.path"></u-image>						
						<audio v-if="test.type==2" :src="item.path"  controls />
						<video v-if="test.type==3" :src="item.path" controls />
				</u-cell-item>
				
				<u-form-item v-for="(category, index2) in categorys" :key="index2" :label="category.value" label-width="150">
						<view v-for="(rank, index3) in ranks" :key="index3">
							{{ rank.value }}:{{getRankCnt(item.id,category.id,rank.id)}}票,
						</view>					
				</u-form-item>			
			</u-cell-group>

		<ylh-tabbar></ylh-tabbar>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: "测试详情",
				uid:0,
				tid:0,
				test:{},
				items: [],
				categorys:[],
				ranks:[],
				scores:[],
				scoreMap: new Map(),
			}
		},
		onLoad(options) {
			this.uid = uni.getStorageSync('userID');
			if(!this.uid){
				uni.navigateTo({
				url: '/pages/login/index'
				})
			}
			
			this.tid=parseInt(options.pid);
			this.getTest(options.pid);
			this.getItem(options.pid);
		},
		methods: {
			getTest(id){
				this.$u.api.getTest({id:id}).then(res => {
							if(res  && res.ret) {
								this.test=res.data;
							}
					})								
			},
			getRankCnt(iid,cid,rid){
				if(this.scoreMap.has(iid)){
					let s2=this.scoreMap.get(iid);
					if(s2.has(cid)){
						let s3=s2.get(cid);
						if(s3.has(rid)){
							return s3.get(rid);
						}
					}
				}
				return 0;
			},
			getItem(pid) {
				this.$u.api.getItemList({
					pid: pid
				}).then(ret => {
					this.items = ret;
					this.getCategory();					
				})
			},
			getCategory() {
				this.$u.api.getCategoryList({					
				}).then(ret => {
					this.categorys = ret;
					this.getRank();
					this.getScore();								
				})
			},
			getRank() {
				this.$u.api.getRankList({				
				}).then(ret => {
					this.ranks = ret;
				})
			},	
			getScore(uid,tid) {
				this.$u.api.getScoreList({
					uid: this.uid, tid: this.tid
				}).then(ret => {
					//console.log(ret);
					this.scores = ret;
					let scoreMap = new Map();
					for(let s of ret){
						if(!scoreMap.has(s.iid)) {
							scoreMap.set(s.iid,new Map());
						}
						let s2=scoreMap.get(s.iid);
						if(!s2.has(s.cid)) {
							s2.set(s.cid,new Map());
						}
						let s3=s2.get(s.cid);
						if(!s3.has(s.rid)) {
							s3.set(s.rid,0);
						}						
						let cnt=s3.get(s.rid);
						cnt ++;
						s3.set(s.rid,cnt);
					}
					console.log(scoreMap);
					this.scoreMap = scoreMap;
				})
			},
			
		}
	}
</script>

<style lang="scss">
	page {
		background-color: #ededed;
	}

	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.u-form-item--right__content__slot {
		justify-content: space-between;
	}
</style>
