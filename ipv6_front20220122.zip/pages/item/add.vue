<template>
	<view class="content">
		<ylh-navbar :title="title"></ylh-navbar>

		<u-form class="add_form">		
			<u-form-item label-width="130" label="标题">
				<u-input type="text" v-model="data.name" />
			</u-form-item>

			<u-form-item label-width="130" label="文件">
				<u-upload v-model="data.path" ref="uUploadMultiple" :file-list="multipleFiles" :action="action"
					:accept="accept2" :max-size="100 * 1024 * 1024" @oversize="oversize" :sizeType="sizeType"
					:show-progress="true" :auto-upload="true" max-count="1" width="150" height="150"
					:previewFullImage="true"  uploadText="上传文件" :limitType="limitType2" :header="header"
					>
				</u-upload>
				支持类型：{{limitType2}}
			</u-form-item>

			<u-form-item label-width="130" label="类型">
				<u-input type="text" v-model="data.type" />
			</u-form-item>

			<u-form-item label-width="130" label="序号">
				<u-input type="text" v-model="data.seq" />
			</u-form-item>

			<u-button class="bottom-button" type="primary" size="default" @click="submit">添加</u-button>
		</u-form>

		<ylh-tabbar></ylh-tabbar>
	</view>
</template>

<script>
	import {
		HTTP_REQUEST_URL,TOKENNAME
	} from '@/config/app.js';

	export default {
		data() {
			return {
				title: "添加条目",
				
				data: {
					pid:0,
					name: '',
					path: '',
					type: '',
					seq:  '',
				},
				
				action: HTTP_REQUEST_URL + '/api/helper/upload',
				fileList: [],
				multipleFiles: [],
				sizeType: ['original'],		
				limitType2: [],
			    limitType: [
					[],
					['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp', 'jp2', 'image'],
					['mp3','ogg','wav'],
					['mp4','ogg','webm'],
				],
				accept2:'',
				accept:[
					'','image/*','audio/*','video/*'
				],
				header: {},
				tid:0,
			}
		},
		onLoad(options){
			const token = uni.getStorageSync('token');
			if(token) this.header[TOKENNAME] = token;
			this.data.pid=this.tid=options.tid;
		},
		onShow() {
			this.getTest(this.tid);						
		},
		methods: {
			getTest(id){
				this.$u.api.getTest({id:id}).then(res => {
					//console.log(res);
						if(res  && res.ret) {
							let test = res.data;
							this.limitType2 = this.limitType[test.type];
							this.accept2 = this.accept[test.type];
						}
				})				
			},			
			oversize() {
				uni.showToast({
					title: "上传文件不能超过100M",
					icon: 'none'
				})
			},
			onRemove(index, lists) {
				// console.log('已被移除')
			},
			collectFiles() {
				let files = [];
				// 通过filter，筛选出上传进度为100的文件(因为某些上传失败的文件，进度值不为100，这个是可选的操作)
				files = this.$refs.uUploadMultiple.lists.filter(val => {
					return val.progress == 100;
				})
				//console.log(this.$refs.uUploadMultiple.lists)
				// 如果您不需要进行太多的处理，直接如下即可
				// files = this.$refs.uUpload.lists;
				//console.log(files);		
				let files2 = [];
				for (let i = 0; i < files.length; i++) {
					let file = files[i];
					if (!file.response) {
						files2.push(file.url);
					} else if (file.response.code == 200) {
						//console.log(file.response.data.data);
						files2 = files2.concat(file.response.data.data);
					}
				}
				//console.log(files2);
				if(files2.length==1) return files2[0];
				return '';
			},
			submit() {
				//console.log(this.data);return;
				this.data.path=this.collectFiles();
				this.$u.api.addItem(this.data).then(res => {
					if (res && res.ret) {					
						uni.showModal({
							title:"消息",
							content: "添加成功",
							showCancel:false,
							success(res){
								uni.navigateBack()
							}
						})
					}
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.add_form {
		padding: 0rpx 30rpx;
		width: 100%;
	}

	.custom-style {
		margin-left: unset;
	}


	/*    .u-form-item--left{ 
		flex:0 0 140rpx !important; 
	}*/
	
	.bangzhu{
		position: fixed;
		_position:absolute;
		right: 5px;
		bottom: 120px;
		word-break:break-all;
	}	
	.bottom-button {
		margin-top: 20rpx;
		margin-bottom: 20rpx;
	}
</style>
