<template>
	<view>
		<ylh-navbar :title="title"></ylh-navbar>

		<u-cell-group class="test" v-for="(test, index) in tests" :key="index">
			<u-cell-item label-width="130" :label="test.title" :arrow="false"  @click="showTest(test.id)">
				{{test.content}}
			</u-cell-item>
		</u-cell-group>
		<ylh-tabbar></ylh-tabbar>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: "图片",
				tests: [],
			}
		},
		onShow() {
		this.getTestList(1);
		},
		methods: {
			// 页面数据
			getTestList(type) {
				this.$u.api.getTestList({
					type: type,
				}).then(res => {
					console.log(res);
					this.tests = res;
				})
			},

			showTest(id) {
				console.log(id);
				uni.navigateTo({
					url: `/pages/test/show?pid=${id}`
				})

			},

		}
	}
</script>

<style lang="scss" scoped>
	page {
		background-color: #ededed;
	}

	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}
</style>
