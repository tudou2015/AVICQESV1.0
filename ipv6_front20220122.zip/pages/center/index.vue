<template>
	<view>
		<ylh-navbar :title="title"></ylh-navbar>
		<view class="face">
			<u-icon class="img" :name="'/static/emergence-photo.png'" size="150"></u-icon>
			<view class="title">{{user.name}}</view>
		</view>
		<u-grid :col="4">
			<u-grid-item @click="toTest()">
				<u-icon name="/static/my_task.png" :size="80"></u-icon>
				<view class="grid-text">测试管理</view>
			</u-grid-item>
			<u-grid-item @click="toCategory()">
				<u-icon name="/static/department.png" :size="80"></u-icon>
				<view class="grid-text">类别管理</view>
			</u-grid-item>
			<u-grid-item @click="toRank()">
				<u-icon name="/static/top2.png" :size="98"></u-icon>
				<view class="grid-text">等级管理</view>
			</u-grid-item>
			<u-grid-item @click="toStat()">
				<u-icon name="/static/top-active.png" :size="80"></u-icon>
				<view class="grid-text">统计管理</view>
			</u-grid-item>
			<u-grid-item @click="toUser()">
				<u-icon name="/static/my_count.png" :size="80"></u-icon>
				<view class="grid-text">用户管理</view>
			</u-grid-item>
			<u-grid-item @click="toConfig()">
				<u-icon name="/static/manage_count.png" :size="80"></u-icon>
				<view class="grid-text">配置管理</view>
			</u-grid-item>
		</u-grid>


		<ylh-tabbar></ylh-tabbar>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: '个人中心',
				typeStr: '',
				user: {
					type: 0
				}
			}
		},
		onShow() {
			// console.log('onShow');
			this.$u.api.checkToken().then(res => {
				if (res.ret) {
					let user = this.user = res.user;
					if (user.type == 1) this.typeStr = '管理员';
					else this.typeStr = '普通用户';
				}else{
					uni.showModal({
						title: "需要登录",
						content: res.message,
						showCancel:false,
						success(res) {
							if (res.confirm) {
								uni.navigateTo({
									url: '/pages/login/index'
								})
							}
						}
					});
					
				}
			});
		},
		methods: {
			toTest() {
				uni.navigateTo({
					url: '/pages/test/manage'
				})
			},
			toCategory() {
				uni.navigateTo({
					url: '/pages/category/manage'
				})
			},
			toRank() {
				uni.navigateTo({
					url: '/pages/rank/manage'
				})
			},
			toStat() {
				uni.navigateTo({
					url: '/pages/test/stat'
				})
			},
			toUser() {
				uni.navigateTo({
					url: '/pages/user/manage'
				})
			},
			toConfig() {
				uni.navigateTo({
					url: '/pages/center/config'
				})
			},


		}
	}
</script>

<style lang="scss" scoped>
	page {
		background-color: #ededed;
	}

	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.face {
		width: 100%;
		height: 300rpx;
		padding: 80rpx 30rpx;
		//background-color: rgb(95, 148, 224); //rgb(94, 152, 225);
		text-align: center;
		font-size: 28rpx;
		color: #ffffff;
		background: linear-gradient(to bottom, #0099ff 0%,#00eeff 100%);

		.title {}
	}

	.u-grid-admin {
		background-color: white;
	}
</style>
