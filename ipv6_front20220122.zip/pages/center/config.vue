<template>
	<view class="content">
		<ylh-navbar :title="title"></ylh-navbar>

		<u-form class="add_form">
			<u-form-item label="接口" label-width="150">
				<u-radio-group v-model="url" :wrap="true">
					<u-radio  shape="circle" v-for="(item, index) in urlMap" :key="index" :name="item.value">{{ item.label }}({{item.value}})
					</u-radio>
				</u-radio-group>
			</u-form-item>

			<u-button class="bottom-button" type="primary" size="default" @click="submit">修改</u-button>
		</u-form>

		<ylh-tabbar></ylh-tabbar>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: "配置管理",
				urlMap: [
					{
						value:'https://ip46.ahtvu.ah.cn',
						label:'测试环境，支持ipv4和ipv6双栈访问'
						},
					{
						value:'http://ip6.ahou.edu.cn',
						label:'正式环境，只支持ipv6访问'
					}
					
				],
				url: '',
			}
		},
		onLoad(){
			this.url = uni.getStorageSync('domain');
		},
		methods: {
			submit() {
				console.log(this.url);
				if(!this.url) return;
				uni.setStorage({
					key: 'domain',
					data: this.url,
					success: function() {
						uni.showToast({
							title: "修改成功",
							success:location.reload()
						})
					}
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.add_form {
		padding: 0rpx 30rpx;
		width: 100%;
	}

	.custom-style {
		margin-left: unset;
	}


	/*    .u-form-item--left{ 
		flex:0 0 140rpx !important; 
	}*/

	.bangzhu {
		position: fixed;
		_position: absolute;
		right: 5px;
		bottom: 120px;
		word-break: break-all;
	}

	.bottom-button {
		margin-top: 20rpx;
		margin-bottom: 20rpx;
	}
</style>
