<template>
	<view class="content">
		<ylh-navbar :title="title"></ylh-navbar>
		
		
		<view class="uni-container">
			<uni-table ref="table" :loading="loading" border stripe type="false" emptyText="暂无更多数据"
				>
				<uni-tr>
					<uni-th align="center">ID</uni-th>
					<uni-th align="center">类型</uni-th>
					<uni-th align="center">描述</uni-th>
				    <uni-th align="center">操作</uni-th>					
				</uni-tr>
				<uni-tr v-for="(item, index) in tableData" :key="index">
					<uni-td align="center">{{item.id}}</uni-td>
					<uni-td align="center">{{item.type}}</uni-td>
					<uni-td align="center">{{item.value}}</uni-td>					
					<uni-td>
							<view class="uni-group">
								<button class="uni-button" size="mini" type="primary"
									@click="gotoEdit(item.id)">修改</button>
							</view>
					</uni-td>
				</uni-tr>
			</uni-table>
		</view>

	    <ylh-tabbar></ylh-tabbar>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: '类别列表',
				tableData: [],
				loading: false,
			}
		},
		onShow(){
			this.getData();
		},
		methods: {			
			// 获取数据
			getData() {
				this.loading = true;
				this.$u.api.getCategoryList().then(res=>{		
					//console.log(res);
					this.tableData = res;
					this.total = res.length;
					this.loading = false;
				}
			  );
			},			
			gotoAdd() {
				uni.navigateTo({
					url:'/pages/category/add'
				})
			},			
			gotoEdit(id) {
				uni.navigateTo({
					url:'/pages/category/edit?id='+id
				})
			},			
			gotoDelete(id) {
				let that = this;
				uni.showModal({
					title: '提示',
					cancelText: '取消',
					confirmText: '确定',
					content: '确认删除该项？',
					success: function(res) {
						if (res.confirm) {
							that.doDel(id);
						} else if (res.cancel) {}
					}
				});			
			},						
			doDel(id) {
				let that = this;
				that.$u.api.delcategory({
					id: id
				}).then(res => {
					if(res.ret){
						uni.showModal({
							tilte:"消息",
							content:"删除成功",
							showCancel:false,
							success(res){
								that.getData()
							}
						})
					}
				});
			},			
		}
	}
</script>




<style>
	/* #ifndef H5 */
	page {
		padding-top: 85px;
	}

	/* #endif */
	.uni-group {
		display: flex;
		align-items: center;
		margin: 0 auto;
	}

	.yellow {
		background: #ee8a12;
	}

	.green {
		background: #27b08a;
	}
	
	.title{
		color: #4687b6;
	}
</style>
