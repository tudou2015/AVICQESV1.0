package com.qtdszws.ipv6.score;

import java.util.List;

import com.baomidou.mybatisplus.extension.service.IService;
import com.github.pagehelper.PageInfo;

public interface ScoreService  extends IService<Score> {

	List<Score>  getList(Score score);
	void saveScores(List<Score> iScores,List<Score> uScores);
	
}
