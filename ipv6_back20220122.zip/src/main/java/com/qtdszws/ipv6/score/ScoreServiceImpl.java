package com.qtdszws.ipv6.score;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.common.CommonPage;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.qtdszws.ipv6.dao.ScoreDao;



@Service
public class ScoreServiceImpl extends ServiceImpl<ScoreDao, Score> implements ScoreService {

    private Logger logger = LoggerFactory.getLogger(ScoreServiceImpl.class);

    @Resource
    private ScoreDao dao;

	@Override
	public List<Score> getList(Score score) {
        LambdaQueryWrapper<Score> lambdaQueryWrapper = Wrappers.lambdaQuery();
        if(score.getUid()!=0) {
        	lambdaQueryWrapper.eq(Score::getUid,score.getUid());
        }
        if(score.getTid()!=0) {
        	lambdaQueryWrapper.eq(Score::getTid,score.getTid());
        }
        if(score.getIid()!=0) {
        	lambdaQueryWrapper.eq(Score::getIid,score.getIid());
        }
        if(score.getCid()!=0) {
        	lambdaQueryWrapper.eq(Score::getCid,score.getCid());
        }
        List<Score> scoreList = dao.selectList(lambdaQueryWrapper);
        return scoreList;
	}
	
	@Override
	public void saveScores(List<Score> iScores,List<Score> uScores) {
		for(Score score:iScores ) {
			dao.insert(score);
		}
		for(Score score:uScores ) {
			dao.updateById(score);
		}		
	}
	

}
