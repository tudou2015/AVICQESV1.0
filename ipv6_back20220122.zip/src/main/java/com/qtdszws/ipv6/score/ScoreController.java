package com.qtdszws.ipv6.score;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.common.CommonPage;
import com.common.CommonResult;
import com.common.PageParamRequest;
import com.github.pagehelper.PageInfo;
import com.qtdszws.ipv6.util.Session;
import com.qtdszws.ipv6.user.*;
import com.qtdszws.ipv6.test.*;
import com.qtdszws.ipv6.item.*;
import com.qtdszws.ipv6.category.*;
import com.qtdszws.ipv6.rank.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("api/score")
@Api(tags = "Score管理")
public class ScoreController {

	@Autowired
	private ScoreService scoreService;

	@Autowired
	private UserService userService;

	@Autowired
	private TestService testService;

	@Autowired
	private ItemService itemService;

	@Autowired
	private CategoryService categoryService;

	@Autowired
	private RankService rankService;

	@ApiOperation(value = "列表")
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public CommonResult<Object> getList(Score score) {
		List<Score> scoreList = scoreService.getList(score);
		return CommonResult.success(scoreList);
	}

	@ApiOperation(value = "保存")
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	@ApiImplicitParam(name = "scores", value = "SCORES")
	public CommonResult<Object> saveScores(@RequestBody HashMap<String, String> map) {
		HashMap<String, Object> ret = new HashMap<String, Object>();
		try {

			// 操作使用fastjson进行字符串对象转换

			List<Score> scores = new ArrayList<>();

			JSONObject json = new JSONObject();

			JSONArray jsonArray = JSONArray.parseArray(map.get("scores"));

			for (int i = 0; i < jsonArray.size(); i++) {

				JSONObject jsonResult = jsonArray.getJSONObject(i);

				Score score = JSONObject.toJavaObject(jsonResult, Score.class);

				scores.add(score);
			}

			//常规检查
			
			//检查user
			Object UserID = Session.get("userID");
			if (UserID == null) {
				throw new Exception("还未登录");
			}

			User user = userService.getById((Integer) UserID);
			if (user == null) {
				throw new Exception("用户不存在");
			}
			
			
			if(scores.size()==0) {
				throw new Exception("score列表为空");
			}
			
			Score score=scores.get(0);

			//检查tid
			Integer tid=score.getTid();
			Test test = testService.getById(tid);
			if(test == null) {
				throw new Exception("test为空");
			}
			
			//准备item,category,rank
			List<Item> items = itemService.getList(tid);
			HashMap<Integer,Item> itemMap = new HashMap<Integer, Item>();
			
			for(Item item:items) {
				itemMap.put(item.getId(), item);
			}
			
			List<Category> categorys = categoryService.getList();
			HashMap<Integer,Category> categoryMap = new HashMap<Integer, Category>();
			
			for(Category category:categorys) {
				categoryMap.put(category.getId(), category);
			}

			List<Rank> ranks = rankService.getList();
			HashMap<Integer,Rank> rankMap = new HashMap<Integer, Rank>();
			
			for(Rank rank:ranks) {
				rankMap.put(rank.getId(), rank);
			}

			//大小检查
			if(scores.size() != items.size()*categorys.size()) {
				throw new Exception("scores size不一致");
			}
			
			//健康检查
			for (Score score2 : scores) {
				if(score2.getUid()!=user.getId()) {
					throw new Exception("uid不一致");
				}
				if(score2.getTid()!=test.getId()) {
					throw new Exception("tid不一致");
				}
				if(!itemMap.containsKey(score2.getIid())) {
					throw new Exception("iid无效");
				}
				if(!categoryMap.containsKey(score2.getCid())) {
					throw new Exception("cid无效");
				}
				if(!rankMap.containsKey(score2.getRid())) {
					throw new Exception("rid无效");
				}
			}
			
			Score score3 = new Score();
			score3.setUid(user.getId());
			score3.setTid(test.getId());
			List<Score> scoreList = scoreService.getList(score3);
						
			HashMap<Integer,Score> scoreMap = new HashMap<Integer, Score>();
			HashMap<Integer,HashMap<Integer,Score>> orig_iid_cid_map = new HashMap<Integer, HashMap<Integer,Score>>();
			for(Score score4:scoreList) {
				scoreMap.put(score4.getId(), score4);

				if(!orig_iid_cid_map.containsKey(score4.getIid())) {
					orig_iid_cid_map.put(score4.getIid(),new HashMap<Integer, Score>());
				}
				HashMap<Integer,Score> cid_map= orig_iid_cid_map.get(score4.getIid());
				if(!cid_map.containsKey(score4.getCid())) {
					cid_map.put(score4.getCid(), score);
				}else {
					throw new Exception("orig_iid_cid冲突");
				}
			}
			
			List<Score> insertScores = new ArrayList<>();
			List<Score> updateScores = new ArrayList<>();
			
						
			HashMap<Integer,HashMap<Integer,Score>> new_iid_cid_map = new HashMap<Integer, HashMap<Integer,Score>>();
			for(Score score5:scores) {				
				if(!new_iid_cid_map.containsKey(score5.getIid())) {
					new_iid_cid_map.put(score5.getIid(),new HashMap<Integer, Score>());
				}
				HashMap<Integer,Score> cid_map= new_iid_cid_map.get(score5.getIid());
				if(!cid_map.containsKey(score5.getCid())) {
					cid_map.put(score5.getCid(), score);
				}else {
					throw new Exception("new_iid_cid冲突");
				}

				if(scoreMap.containsKey(score5.getId())){
					Score score6=scoreMap.get(score5.getId());
					if(score6.getTid()!=score5.getTid()
					||score6.getIid()!=score5.getIid()
					||score6.getCid()!=score5.getCid()												
					) {
						throw new Exception("score信息不一致");
					}
					if(score6.getRid() != score5.getRid()) {
						updateScores.add(score5);
					}
				}else if(score5.getId() == 0){
					if(orig_iid_cid_map.containsKey(score5.getIid())) {
						HashMap<Integer,Score> iid_cid_map2 =  orig_iid_cid_map.get(score5.getIid());
						if(iid_cid_map2.containsKey(score5.getCid())) {
							throw new Exception("insert score其实已经存在");
						}
					}
					insertScores.add(score5);
				}else {
					throw new Exception("score id无效");
				}
			}
			
			scoreService.saveScores(insertScores,updateScores);
			ret.put("ret", true);
		} catch (Exception ex) {
			ret.put("ret", false);
			ret.put("message", ex.getMessage());
		}

		return CommonResult.success(ret);
	}

}
