package com.qtdszws.ipv6.item;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.common.CommonPage;
import com.common.CommonResult;
import com.common.PageParamRequest;
import com.github.pagehelper.PageInfo;
import com.qtdszws.ipv6.item.*;
import com.qtdszws.ipv6.score.ScoreService;
import com.qtdszws.ipv6.score.Score;
import com.qtdszws.ipv6.test.Test;
import com.qtdszws.ipv6.user.User;
import com.utils.ThreadLocalUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("api/item")
@Api(tags = "Item管理")
public class ItemController {

	@Value("${uploadFile}")
    private String picFolder;

    @Autowired
    private ItemService itemService;

    @Autowired
    private ScoreService scoreService;

    @ApiOperation(value = "列表")
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public CommonResult<Object>  getList(@RequestParam(value = "pid") Integer pid){
    	List<Item> itemList= itemService.getList(pid);
        return CommonResult.success(itemList);
    }

    
	@ApiOperation(value = "添加")
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public CommonResult<Object> add(@RequestBody Item item) {
		try {

			if (StringUtils.isBlank(item.getName())) {
				throw new Exception("name不能为空");
			}

			if (StringUtils.isBlank(item.getPath())) {
				throw new Exception("path不能为空");
			}
			
			//http://10.1.11.5:58080/upload/2021/12/21/10098ca80c804978bcbcfae1bbbb0d4f.jpg
			String path = item.getPath();
			int pos = path.indexOf("/upload/");
			if(pos == -1) {
				throw new Exception("path格式无效");	
			}
			String path2 = path.substring(pos + 7);
            File file = new File(picFolder + path2);
            if(!file.exists()) {
            	throw new Exception("文件不存在");	
            }

			if (StringUtils.isBlank(item.getType())) {
				throw new Exception("type不能为空");
			}
			
			User my = ThreadLocalUtil.get("user");
			// 确认管理员身份
			if (my.getType() != 1) {
				return CommonResult.failed("无权操作");
			}

			HashMap<String, Object> ret = new HashMap<String, Object>();
			ret.put("ret", itemService.save(item));
			return CommonResult.success(ret);
		} catch (Exception ex) {
			return CommonResult.failed(ex.getMessage());
		}
	}

	
    @ApiOperation(value = "详情")
    @RequestMapping(value = "/get", method = RequestMethod.GET)
    @ApiImplicitParam(name="id", value="ID")
    public CommonResult<Object> get(@RequestParam(value = "id") Integer id){
    	try {
            Item item = itemService.getById(id);

            HashMap<String,Object> ret =new  HashMap<String, Object>();
            ret.put("ret", item != null);
            ret.put("data", item);
            return CommonResult.success(ret);
    	}catch(Exception ex) 
    	{
    		return CommonResult.failed(ex.getMessage());
    	}
    }
    
    @ApiOperation(value = "编辑")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public CommonResult<Object> update(@RequestBody Item item){
        try {
            Item item2 = itemService.getById(item.getId());
        	if(item2 == null) {
        		throw new Exception("id无效");
        	}
        	
			if (StringUtils.isBlank(item.getName())) {
				throw new Exception("name不能为空");
			}

			if (StringUtils.isBlank(item.getPath())) {
				throw new Exception("path不能为空");
			}
			
			//http://10.1.11.5:58080/upload/2021/12/21/10098ca80c804978bcbcfae1bbbb0d4f.jpg
			String path = item.getPath();
			int pos = path.indexOf("/upload/");
			if(pos == -1) {
				throw new Exception("path格式无效");	
			}
			String path2 = path.substring(pos + 7);
            File file = new File(picFolder + path2);
            if(!file.exists()) {
            	throw new Exception("文件不存在");	
            }

			if (StringUtils.isBlank(item.getType())) {
				throw new Exception("type不能为空");
			}

			User my = ThreadLocalUtil.get("user");
			// 确认管理员身份
			if (my.getType() != 1) {
				return CommonResult.failed("无权操作");
			}
			
            HashMap<String,Object> ret = new  HashMap<String, Object>();
            ret.put("ret", itemService.updateById(item));
            return CommonResult.success(ret);
        }catch (Exception ex) {
            return CommonResult.failed(ex.getMessage());
        }
    }    
    
    @ApiOperation(value = "删除")
    @RequestMapping(value = "/del", method = RequestMethod.GET)
    @ApiImplicitParam(name="id", value="ID")
    public CommonResult<Object> del(@RequestParam(value = "id") Integer id){
        try {
        	Item item = itemService.getById(id);
        	if(item == null) {
        		throw new Exception("id无效");
        	}
        	Score score = new Score();
        	score.setIid(id);
        	if(scoreService.getList(score).size()>0) {
        		return CommonResult.failed("有关联数据");
        	}
        	
            User my = ThreadLocalUtil.get("user");
            //确认管理员身份
            if (my.getType() != 1)
                return CommonResult.failed("无权操作");
            
            HashMap<String,Object> ret =new  HashMap<String, Object>();
            ret.put("ret", itemService.removeById(id));
            return CommonResult.success(ret);
        }catch (Exception ex) {
                return CommonResult.failed(ex.getMessage());
           }
    }    
    
}
