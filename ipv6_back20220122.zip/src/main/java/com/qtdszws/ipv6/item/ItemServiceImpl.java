package com.qtdszws.ipv6.item;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.common.CommonPage;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.qtdszws.ipv6.dao.ItemDao;
import com.qtdszws.ipv6.item.Item;
import com.qtdszws.ipv6.item.ItemService;

@Service
public class ItemServiceImpl extends ServiceImpl<ItemDao, Item> implements ItemService {

    private Logger logger = LoggerFactory.getLogger(ItemServiceImpl.class);

    @Resource
    private ItemDao dao;

	@Override
	public List<Item> getList(Integer pid) {
        LambdaQueryWrapper<Item> lambdaQueryWrapper = Wrappers.lambdaQuery();
        lambdaQueryWrapper.eq(Item::getPid, pid);
        lambdaQueryWrapper.orderByAsc(Item::getSeq);
        List<Item> itemList = dao.selectList(lambdaQueryWrapper);
        return itemList;
	}

}
