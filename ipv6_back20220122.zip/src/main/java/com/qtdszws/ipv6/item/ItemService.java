package com.qtdszws.ipv6.item;

import java.util.List;

import com.baomidou.mybatisplus.extension.service.IService;
import com.github.pagehelper.PageInfo;

public interface ItemService  extends IService<Item> {

	List<Item>  getList(Integer pid);
	
}
