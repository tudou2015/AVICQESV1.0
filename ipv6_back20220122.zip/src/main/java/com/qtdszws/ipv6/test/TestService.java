package com.qtdszws.ipv6.test;

import java.util.List;

import com.baomidou.mybatisplus.extension.service.IService;
import com.github.pagehelper.PageInfo;

public interface TestService  extends IService<Test> {

	List<Test>  getList(int type);
	
}
