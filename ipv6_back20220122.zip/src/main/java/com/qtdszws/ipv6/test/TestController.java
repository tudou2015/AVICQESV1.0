package com.qtdszws.ipv6.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.common.CommonPage;
import com.common.CommonResult;
import com.common.PageParamRequest;
import com.github.pagehelper.PageInfo;
import com.qtdszws.ipv6.item.ItemService;
import com.qtdszws.ipv6.test.Test;
import com.qtdszws.ipv6.test.TestController;
import com.qtdszws.ipv6.test.TestService;
import com.qtdszws.ipv6.user.User;
import com.utils.ThreadLocalUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("api/test")
@Api(tags = "测试管理")
public class TestController {

	@Autowired
	private TestService testService;

	@Autowired
	private ItemService itemService;

	@ApiOperation(value = "列表")
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public CommonResult<Object> getList(@RequestParam(value = "type") Integer type) {
		List<Test> testList = testService.getList(type);
		return CommonResult.success(testList);
	}

	@ApiOperation(value = "添加")
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public CommonResult<Object> add(@RequestBody Test test) {
		try {
			int type = test.getType();
			if (type < 1 || type > 3) {
				throw new Exception("type无效");
			}

			if (StringUtils.isBlank(test.getTitle())) {
				throw new Exception("title不能为空");
			}

			if (StringUtils.isBlank(test.getContent())) {
				throw new Exception("content不能为空");
			}

			User my = ThreadLocalUtil.get("user");
			// 确认管理员身份
			if (my.getType() != 1) {
				return CommonResult.failed("无权操作");
			}

			HashMap<String, Object> ret = new HashMap<String, Object>();
			ret.put("ret", testService.save(test));
			return CommonResult.success(ret);
		} catch (Exception ex) {
			return CommonResult.failed(ex.getMessage());
		}
	}

	
    @ApiOperation(value = "详情")
    @RequestMapping(value = "/get", method = RequestMethod.GET)
    @ApiImplicitParam(name="id", value="ID")
    public CommonResult<Object> get(@RequestParam(value = "id") Integer id){
    	try {
            Test test = testService.getById(id);

            HashMap<String,Object> ret =new  HashMap<String, Object>();
            ret.put("ret", test != null);
            ret.put("data", test);
            return CommonResult.success(ret);
    	}catch(Exception ex) 
    	{
    		return CommonResult.failed(ex.getMessage());
    	}
    }
    
    @ApiOperation(value = "编辑")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public CommonResult<Object> update(@RequestBody Test test){
        try {
            Test test2 = testService.getById(test.getId());
        	if(test2 == null) {
        		throw new Exception("id无效");
        	}
        	
			if (StringUtils.isBlank(test.getTitle())) {
				throw new Exception("title不能为空");
			}

			if (StringUtils.isBlank(test.getContent())) {
				throw new Exception("content不能为空");
			}

			User my = ThreadLocalUtil.get("user");
			// 确认管理员身份
			if (my.getType() != 1) {
				return CommonResult.failed("无权操作");
			}
			
            HashMap<String,Object> ret = new  HashMap<String, Object>();
            ret.put("ret", testService.updateById(test));
            return CommonResult.success(ret);
        }catch (Exception ex) {
            return CommonResult.failed(ex.getMessage());
        }
    }    
    
    @ApiOperation(value = "删除")
    @RequestMapping(value = "/del", method = RequestMethod.GET)
    @ApiImplicitParam(name="id", value="ID")
    public CommonResult<Object> del(@RequestParam(value = "id") Integer id){
        try {
        	Test test = testService.getById(id);
        	if(test == null) {
        		throw new Exception("id无效");
        	}
        	
        	if(itemService.getList(id).size()>0) {
        		return CommonResult.failed("有关联数据");
        	}
        	
            User my = ThreadLocalUtil.get("user");
            //确认管理员身份
            if (my.getType() != 1)
                return CommonResult.failed("无权操作");
            
            HashMap<String,Object> ret =new  HashMap<String, Object>();
            ret.put("ret", testService.removeById(id));
            return CommonResult.success(ret);
        }catch (Exception ex) {
                return CommonResult.failed(ex.getMessage());
           }
    }    
}
