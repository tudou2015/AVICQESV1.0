package com.qtdszws.ipv6.test;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.common.CommonPage;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.qtdszws.ipv6.dao.TestDao;
import com.qtdszws.ipv6.test.Test;
import com.qtdszws.ipv6.test.TestService;

@Service
public class TestServiceImpl extends ServiceImpl<TestDao, Test> implements TestService {

    private Logger logger = LoggerFactory.getLogger(TestServiceImpl.class);

    @Resource
    private TestDao dao;

	@Override
	public List<Test> getList(int type) {
        LambdaQueryWrapper<Test> lambdaQueryWrapper = Wrappers.lambdaQuery();
        if(type !=0 ) {
        	lambdaQueryWrapper.eq(Test::getType, type);
        }
        //lambdaQueryWrapper.orderByAsc(Category::getName);
        List<Test> taskList = dao.selectList(lambdaQueryWrapper);
        return taskList;
	}

}
