package com.qtdszws.ipv6.test;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("ipv6_test")
@ApiModel(value="Test对象", description="测试")
public class Test  implements Serializable {
	
    private static final long serialVersionUID=1L;
    
	  @ApiModelProperty(value = "ID")
	    @TableId(value = "id", type = IdType.AUTO)
	    private Integer id;
	  
	  	private Integer type;

	    @ApiModelProperty(value = "标题")
	    private String title;
	    
	    @ApiModelProperty(value = "描述")
	    private String content;

	    @ApiModelProperty(value = "删除标志")
	    @TableLogic
	    @TableField(select = false)    
	    private Integer deleted;	    
}
