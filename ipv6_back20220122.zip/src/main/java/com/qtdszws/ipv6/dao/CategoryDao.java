package com.qtdszws.ipv6.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.qtdszws.ipv6.category.Category;

public interface CategoryDao extends BaseMapper<Category> {

}
