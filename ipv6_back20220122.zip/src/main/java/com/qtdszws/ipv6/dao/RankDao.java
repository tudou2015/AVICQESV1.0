package com.qtdszws.ipv6.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.qtdszws.ipv6.rank.Rank;

public interface RankDao extends BaseMapper<Rank> {

}
