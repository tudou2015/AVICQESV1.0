package com.qtdszws.ipv6.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.qtdszws.ipv6.item.Item;

public interface ItemDao extends BaseMapper<Item> {

}
