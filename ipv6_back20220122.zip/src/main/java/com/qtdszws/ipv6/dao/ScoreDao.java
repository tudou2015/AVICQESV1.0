package com.qtdszws.ipv6.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.qtdszws.ipv6.score.Score;

public interface ScoreDao extends BaseMapper<Score> {

}
