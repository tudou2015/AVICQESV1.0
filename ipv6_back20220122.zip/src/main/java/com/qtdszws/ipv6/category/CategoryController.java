package com.qtdszws.ipv6.category;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.common.CommonPage;
import com.common.CommonResult;
import com.common.PageParamRequest;
import com.github.pagehelper.PageInfo;
import com.qtdszws.ipv6.item.*;
import com.qtdszws.ipv6.user.User;
import com.utils.ThreadLocalUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("api/category")
@Api(tags = "Category管理")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @ApiOperation(value = "列表")
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public CommonResult<Object>  getList(){
    	List<Category> categoryList= categoryService.getList();
        return CommonResult.success(categoryList);
    }

    @ApiOperation(value = "详情")
    @RequestMapping(value = "/get", method = RequestMethod.GET)
    @ApiImplicitParam(name="id", value="ID")
    public CommonResult<Object> info(@RequestParam(value = "id") Integer id){
    	try {
            Category category = categoryService.getById(id);

            HashMap<String,Object> ret =new  HashMap<String, Object>();
            ret.put("ret", category != null);
            ret.put("data", category);
            return CommonResult.success(ret);
    	}catch(Exception ex) 
    	{
    		return CommonResult.failed(ex.getMessage());
    	}
    }
    
    @ApiOperation(value = "编辑")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public CommonResult<Object> update(@RequestBody Category category){
        try {
            Category category2 = categoryService.getById(category.getId());
        	if(category2 == null) {
        		throw new Exception("id无效");
        	}
        	
			if (StringUtils.isBlank(category.getValue())) {
				throw new Exception("描述不能为空");
			}

			User my = ThreadLocalUtil.get("user");
			// 确认管理员身份
			if (my.getType() != 1) {
				return CommonResult.failed("无权操作");
			}
			
            HashMap<String,Object> ret = new  HashMap<String, Object>();
            ret.put("ret", categoryService.updateById(category));
            return CommonResult.success(ret);
        }catch (Exception ex) {
            return CommonResult.failed(ex.getMessage());
        }
    }    

}
