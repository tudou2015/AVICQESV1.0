package com.qtdszws.ipv6.user;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("ipv6_user")
@JsonInclude(value= JsonInclude.Include.NON_NULL)
@ApiModel(value = "User对象", description = "用户管理")
public class User implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "用户ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    private Integer type;

    private String name;

    //@TableField(select = false)
    @JsonIgnore
    private String passwd;

    //@TableField(select = false)
    @JsonIgnore
    private String salt;


    @ApiModelProperty(value = "删除标志")
    @TableLogic
    @TableField(select = false)
    private Integer deleted;
}
