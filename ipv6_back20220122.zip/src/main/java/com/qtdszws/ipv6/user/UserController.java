package com.qtdszws.ipv6.user;

import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.common.CommonPage;
import com.common.CommonResult;
import com.common.PageParamRequest;
import com.github.pagehelper.PageInfo;
import com.qtdszws.ipv6.category.Category;
import com.qtdszws.ipv6.util.Session;
import com.qtdszws.ipv6.util.Utils;
import com.utils.RedisUtil;
import com.utils.ThreadLocalUtil;

import cn.hutool.core.util.StrUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;


//@Slf4j
@RestController
@RequestMapping("api/user")
@Api(tags = "用户管理")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    protected RedisUtil redisUtil;


    @ApiOperation(value = "列表")
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public CommonResult<Object>  getList(){
    	List<User> userList= userService.getList();
        return CommonResult.success(userList);
    }


    @ApiOperation(value = "详情")
    @RequestMapping(value = "/get", method = RequestMethod.GET)
    @ApiImplicitParam(name = "id", value = "ID")
    public CommonResult<Object> get(@RequestParam(value = "id") Integer id) {
    	try {
            User user = userService.getById(id);

            HashMap<String,Object> ret =new  HashMap<String, Object>();
            ret.put("ret", user != null);
            ret.put("data", user);
            return CommonResult.success(ret);
    	}catch(Exception ex) 
    	{
    		return CommonResult.failed(ex.getMessage());
    	}
    }

    @ApiOperation(value = "编辑")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public CommonResult<Object> update(@RequestBody HashMap<String,String> map){
        try {
            String id = map.get("id");
            if(StringUtils.isBlank(id)) {
            	throw new Exception("id无效");
            }
            Integer id2 = Integer.parseInt(id);
            User user = userService.getById(id2);
            String oldPasswd = map.get("oldPasswd");
            String newPasswd = map.get("newPasswd");
            String reNewPasswd = map.get("reNewPasswd");

            if (!Utils.isValidStr(oldPasswd) 
            	|| !Utils.isValidStr(newPasswd)
            	|| !Utils.isValidStr(reNewPasswd)
            		) {
                throw new Exception("密码不正确");
            }

            String pass2 = Utils.getPasswordHash(user.getSalt(), oldPasswd);
            if (!user.getPasswd().equals(pass2)) {
                throw new Exception("旧密码不正确！");
            }

            if (!newPasswd.equals(reNewPasswd)) {
                throw new Exception("新密码不一致");
            }

            if (newPasswd.length() < 5) {
                throw new Exception("密码长度不足");
            }

            String code = String.valueOf(new Random().nextLong());
            user.setSalt(code);
            user.setPasswd(Utils.getPasswordHash(code, newPasswd));


            Boolean ret = userService.updateById(user);

            HashMap<String, Object> map2 = new HashMap<String, Object>();
            map2.put("ret", ret);
            return CommonResult.success(map2);
        } catch (Exception ex) {
            return CommonResult.failed(ex.getMessage());
        }
    }    

    
    @ApiOperation(value = "登录")
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public CommonResult<Object> login(@RequestBody HashMap<String, String> map) {
        try {
            String name = map.get("name");
            String passwd = map.get("passwd");
            String code = map.get("code");
            
            if (!Utils.isValidStr(name)  || !Utils.isValidStr(passwd)) {
                throw new Exception("用户名或密码不正确！");
            }
            
            if(code == null || code.length()!=4) {
                throw new Exception("验证码不正确！");
            }
            
            code = code.toLowerCase();
            
            String code2 = (String)Session.get("code");
            if(code2 == null) {
            	throw new Exception("验证码还未生成,请刷新验证码图片！");
            }
            //code2 = code2.toLowerCase();
            
            Integer retry = (Integer)Session.get("retry");
            if(retry>5) {
            	throw new Exception("验证码尝试次数太多，请刷新验证码！");
            }
            retry ++;
            Session.set("retry",retry);
            
            if(!code.equals(code2)) {
            	throw new Exception("验证码不正确！");
            }
            
            User user = userService.getByName(name);

            if (user == null) {
                throw new Exception("手机号或密码不正确！");
            }
            String pass1 = user.getPasswd();
            String pass2 = Utils.getPasswordHash(user.getSalt(), passwd);
            if (!pass1.equals(pass2)) {
                throw new Exception("手机号或密码不正确！");
            }


            String token = Session.GetToken();
            Session.clear();
            
            int userID = (int) user.getId();
            Session.set("userID", userID);

            HashMap<String, Object> ret = new HashMap<String, Object>();
            ret.put("ret", true);
            ret.put("token", token);
            ret.put("userID", user.getId());
            ret.put("user", user);            
            
            return CommonResult.success(ret);
        } catch (Exception ex) {
            return CommonResult.failed(ex.getMessage());
        }
    }

    @ApiOperation(value = "检查token")
    @RequestMapping(value = "/checkToken")
    public CommonResult<Object> checkToken() {
        String msg = "";
        Boolean ret = false;
        User user = null;
        try {
            do {
            	Object UserID = Session.get("userID");
            	if(UserID == null) {
            		msg ="还未登录";
            		break;
            	}
            	
                user = userService.getById((Integer)UserID);
                if (user == null) {
                    msg ="用户不存在";
                    break;
                }

                ret = true;

            } while (false);

            HashMap<String, Object> map = new HashMap<String, Object>();
            map.put("ret", ret);
            map.put("user", user);
            map.put("message", msg);
            return CommonResult.success(map);
        } catch (Exception ex) {
            return CommonResult.failed(ex.getMessage());
        }
    }

   

    @ApiOperation(value = "注册用户")
    @RequestMapping(value = "/reg", method = RequestMethod.POST)
    public CommonResult<Object> reg(HttpServletRequest request, @RequestBody HashMap<String, String> map) {
        try {
            String name = map.get("name");
            String passwd = map.get("passwd");
            String rePasswd = map.get("rePasswd");
            String code = map.get("code");

            if (!Utils.isValidStr(name)) {
                throw new Exception("姓名不正确");
            }

            if (!Utils.isValidStr(passwd) || !Utils.isValidStr(rePasswd)) {
                throw new Exception("密码不正确");
            }

            if (!passwd.equals(rePasswd)) {
                throw new Exception("密码不一致");
            }

            if (passwd.length() < 5) {
                throw new Exception("密码长度不足");
            }

            String savedCode = (String)Session.get("code");
            if (!code.equals(savedCode)) {
                throw new Exception("验证码不正确");
            }

            if (userService.checkName(name) > 0) {
                throw new Exception("该用户名已注册");
            }

            User user = new User();
            user.setName(name);
            code = String.valueOf(new Random().nextLong());
            user.setSalt(code);
            user.setPasswd(Utils.getPasswordHash(code, rePasswd));
            user.setType(2);


            Boolean ret = userService.save(user);
            if (ret) {
                Session.clear();
            }

            HashMap<String, Object> map2 = new HashMap<String, Object>();
            map2.put("ret", ret);
            return CommonResult.success(map2);
        } catch (Exception ex) {
            return CommonResult.failed(ex.getMessage());
        }
        
        
    }



}
