package com.qtdszws.ipv6.user;

import com.baomidou.mybatisplus.extension.service.IService;
import com.common.PageParamRequest;
import com.github.pagehelper.PageInfo;
import com.qtdszws.ipv6.category.Category;

import java.util.List;


public interface UserService extends IService<User> {

	
	List<User>  getList();
	
	User getByName(String name);
    int checkName(String name);

}
