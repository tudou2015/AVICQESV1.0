package com.qtdszws.ipv6.util;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.support.StandardMultipartHttpServletRequest;

import com.alibaba.fastjson.JSONObject;
import com.aliyuncs.utils.Base64Helper;
import com.common.CommonPage;
import com.common.CommonResult;
import com.constants.Constants;
import com.mysql.jdbc.StringUtils;
import com.qtdszws.ipv6.user.User;
import com.utils.RedisUtil;
import com.utils.ThreadLocalUtil;

import cn.hutool.core.codec.Base64;
import cn.hutool.core.lang.UUID;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.DigestUtils;

@Slf4j
@RestController
@RequestMapping("api/helper")
@Api(tags = "帮助管理")
public class HelperController {
	private Logger logger = LoggerFactory.getLogger(HelperController.class);

	@Value("${uploadFile}")
    private String picFolder;
	
	@Value("${picExts}")
    private String picExts;

	@Value("${picMaxSize}")
    private int picMaxSize;
	
    @Autowired
    protected RedisUtil redisUtil;
    

	@ApiOperation(value = "上传")
    @RequestMapping(value = "/upload")
    public CommonResult<Object> upload(HttpServletRequest request){
          try {
        	  
        	   User user = ThreadLocalUtil.get("user");
        	   
        	   if(user == null) {
        		  throw new Exception("还未登录");
        	   }
        	          	  
              request.setCharacterEncoding("utf-8");
              StandardMultipartHttpServletRequest req = (StandardMultipartHttpServletRequest) request;
              Iterator<String> iterator = req.getFileNames();
              Calendar    rightNow    =    Calendar.getInstance(); 
              Integer year = rightNow.get(Calendar.YEAR); 
              Integer month = rightNow.get(Calendar.MONTH)+1; //第一个月从0开始，所以得到月份＋1
              Integer day = rightNow.get(rightNow.DAY_OF_MONTH);
              //按年，月，日建树形目录
              String path = picFolder + File.separator + year + File.separator + month +File.separator + day + File.separator;
              File folder = new File(path);
              if(!folder.exists()){
                  folder.mkdirs();
              }
              
              List<String> filePaths = new ArrayList<>();
              String[] picExt2=picExts.split(",");              
              while (iterator.hasNext()) {
                  MultipartFile multipartFile = req.getFile(iterator.next());
                  String originalFirstName = multipartFile.getOriginalFilename();

                  if(multipartFile.getSize()>picMaxSize) {
                	  return CommonResult.failed("file "+originalFirstName +" size invalid,must less then 100MB");
                  }
                  
                  String kzm = originalFirstName.substring(originalFirstName.lastIndexOf(".")+1).toLowerCase();
                  boolean ok = false;
                  for(int i=0;i<picExt2.length;i++) {
                	  if(picExt2[i].equals(kzm)) {
                		  ok = true;
                		  break;                		  
                	  }
                  }
                  if(!ok) {
                	  return CommonResult.failed("file "+originalFirstName +" format invalid,must be "+picExts);
                  }
              }
              
              
              iterator = req.getFileNames();
              while (iterator.hasNext()) {
                  MultipartFile multipartFile = req.getFile(iterator.next());
                  String originalFirstName = multipartFile.getOriginalFilename();
                  String uuid = UUID.randomUUID().toString().replace("-", "");// + "_"+user.getId();
                  String kzm = originalFirstName.substring(originalFirstName.lastIndexOf(".")).toLowerCase();
                  String filename = uuid + kzm;
                  File file = new File(path + filename);
                  //真正写到磁盘上
                  OutputStream out = new FileOutputStream(file);
                  out.write(multipartFile.getBytes());
                  out.close();
                  filePaths.add( 
                		  //request.getScheme() + "://" +
                          //request.getServerName() + ":"
                          //+ request.getServerPort()+                          
                          "/upload/" + year + "/" + month + "/" + day + "/" + filename);
              }
                  System.out.println("图片访问路径："+filePaths);
                  Map<String, Object> map = new HashMap<String,Object>();
                  map.put("data", filePaths);
                  return CommonResult.success(map);
              
          } catch (Exception e) {
              logger.error("error:{}", e.getMessage(), e);
              return CommonResult.failed(e.getMessage());    	
          }
          
    }
	


	@ApiOperation(value = "生成验证码")
	@RequestMapping("/getVerifyCode")
    public Object getVerifiCode(){
        /*
             1.生成验证码
             2.把验证码上的文本存在session中
             3.把验证码图片发送给客户端
             */
		try {
        ImageVerificationCode ivc = new ImageVerificationCode();     //用我们的验证码类，生成验证码类对象
        BufferedImage image = ivc.getImage();  //获取验证码
        //request.getSession().setAttribute("text", ivc.getText()); //将验证码的文本存在session中

        Session.set("code", ivc.getText().toLowerCase());
        Session.set("retry", 0);
        
        ByteArrayOutputStream out= new ByteArrayOutputStream();
        
        ivc.output(image, out);//将验证码图片响应给客户端
        
        String img = "data:image/jpeg;base64,"+Base64Helper.encode(out.toByteArray());
        
        out.close();
        
        HashMap<String, Object> ret = new HashMap<>();
        ret.put("ret", true);
        ret.put("img", img);
        ret.put("token", Session.GetToken());
        
        return CommonResult.success(ret);
		}catch(Exception ex) {
			return CommonResult.failed(ex.getMessage());
		}
    }

	
}
