package com.qtdszws.ipv6.util;

import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.util.DigestUtils;

public class Utils {

	public static String getPasswordHash(String salt,String password) {
		String str=salt+password;
		return DigestUtils.md5DigestAsHex(str.getBytes());		
	}
	
	public static boolean isMobile(String mobile) {
		String regex = "^((13[0-9])|(14[5,7,9])|(15([0-3]|[5-9]))|(16[5,6])|(17[0-8])|(18[0-9])|(19[1、5、8、9]))\\d{8}$";
		Pattern p = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(mobile);
		return m.matches();
		}	

    public static void mkdir(String path) {
        File fd = null;
        try {
            fd = new File(path);
            if (!fd.exists()) {
                fd.mkdirs();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            fd = null;
        }
    }
    
    /*
     * 手机号匿名化处理
     * 13811112222 -> 138****2222
     */
    public static String BlurPhone(String phone) {
    	if(phone == null || phone.length()!=11) return phone;
    	
    	String start = phone.substring(0, 3);
    	String mid = phone.substring(3,7);
    	String end = phone.substring(7,11);
    	
    	return start + "****" + end;
    }
    
    /*
     * 判断字符串是否是数字
     */
    public static boolean isNumeric(String str){

    	if(str == null || str.length()==0) return false;
    	
    	Pattern pattern = Pattern.compile("[0-9]+");

    	return pattern.matcher(str).matches();

    	}
    
    public static boolean isValidStr(String str) {
    	if(str == null) return false;
    	if(str.contains(";"))return false;
    	if(str.contains("\\"))return false;
    	if(str.contains(","))return false;
    	if(str.contains("'"))return false;
    	if(str.contains("\""))return false;
    	return true;
    	
    	
    }
}
