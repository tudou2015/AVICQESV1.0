package com.qtdszws.ipv6.util;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSONObject;
import com.common.CommonResult;
import com.constants.Constants;
import com.mysql.jdbc.StringUtils;
import com.qtdszws.ipv6.user.User;
import com.utils.RedisUtil;
import com.utils.ThreadLocalUtil;

import cn.hutool.core.lang.UUID;

public class Session {
	private String token;
	private JSONObject json;

	private RedisUtil _redisUtil;

	private static Session instance = new Session();

	private Session() {
		token = "";
		json = new JSONObject();
	}

	public static Session getInstance() {
		Session session = ThreadLocalUtil.get("session");
		if(session == null)	session = new Session();
		ThreadLocalUtil.set("session",session);
		return session;
	}

	public static  void Create(HttpServletRequest request,RedisUtil redisUtil,boolean new2) {
		try {

			Session session = getInstance();
			
			if(session.token.length()>0) return;
			
			session.token = request.getHeader(Constants.HEADER_AUTHORIZATION_KEY);
			if (StringUtils.isNullOrEmpty(session.token) && new2) {
				session.token = UUID.randomUUID().toString().replace("-", "");
			} else {
				String json2 = (String) redisUtil.get(Constants.USER_TOKEN_REDIS_KEY_PREFIX + session.token);
				if (json2 != null) {
					session.json = JSONObject.parseObject(json2);
				}
			}

			session._redisUtil = redisUtil;	
			
			ThreadLocalUtil.set("token",session.token);
			
		} catch (Exception ex) {
			System.out.print(ex.getMessage());
		}
	}

	public static Object get(String key) {
		Session session = getInstance();		
		return session.json.get(key);
	}

	public static void set(String key, Object value) {
		Session session = getInstance();
		session.json.put(key, value);
	}

	public static void clear() {
		Session session = getInstance();
		session.json.clear();
	}
	
	public static String GetToken() {
		Session session = getInstance();
		return session.token;
	}
	
	public static void remove(String key) {
		Session session = getInstance();
		session.json.remove(key);
	}
	
	public static void save() {
		Session session = getInstance();
		String json2 = JSONObject.toJSONString(session.json);
		if(json2.length()>0) {
			session._redisUtil.set(Constants.USER_TOKEN_REDIS_KEY_PREFIX + session.token, json2, Constants.TOKEN_EXPRESS_MINUTES,
					TimeUnit.MINUTES);
		}

	}
}
