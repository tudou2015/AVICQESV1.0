package com.qtdszws.ipv6.rank;

import java.util.List;

import com.baomidou.mybatisplus.extension.service.IService;
import com.github.pagehelper.PageInfo;

public interface RankService  extends IService<Rank> {

	List<Rank>  getList();
	
}
