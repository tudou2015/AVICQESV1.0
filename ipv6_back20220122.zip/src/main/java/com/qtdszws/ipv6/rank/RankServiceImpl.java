package com.qtdszws.ipv6.rank;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.common.CommonPage;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.qtdszws.ipv6.dao.RankDao;
import com.qtdszws.ipv6.rank.*;


@Service
public class RankServiceImpl extends ServiceImpl<RankDao, Rank> implements RankService {

    private Logger logger = LoggerFactory.getLogger(RankServiceImpl.class);

    @Resource
    private RankDao dao;

	@Override
	public List<Rank> getList() {
        LambdaQueryWrapper<Rank> lambdaQueryWrapper = Wrappers.lambdaQuery();
        lambdaQueryWrapper.orderByAsc(Rank::getType);
        List<Rank> rankList = dao.selectList(lambdaQueryWrapper);
        return rankList;
	}

}
