package com.qtdszws.ipv6.rank;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.common.CommonPage;
import com.common.CommonResult;
import com.common.PageParamRequest;
import com.github.pagehelper.PageInfo;
import com.qtdszws.ipv6.category.Category;
import com.qtdszws.ipv6.rank.*;
import com.qtdszws.ipv6.user.User;
import com.utils.ThreadLocalUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("api/rank")
@Api(tags = "Rank管理")
public class RankController {

    @Autowired
    private RankService rankService;

    @ApiOperation(value = "列表")
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public CommonResult<Object>  getList(){
    	List<Rank> rankList= rankService.getList();
        return CommonResult.success(rankList);
    }

    @ApiOperation(value = "详情")
    @RequestMapping(value = "/get", method = RequestMethod.GET)
    @ApiImplicitParam(name="id", value="ID")
    public CommonResult<Object> info(@RequestParam(value = "id") Integer id){
    	try {
            Rank rank = rankService.getById(id);

            HashMap<String,Object> ret =new  HashMap<String, Object>();
            ret.put("ret", rank != null);
            ret.put("data", rank);
            return CommonResult.success(ret);
    	}catch(Exception ex) 
    	{
    		return CommonResult.failed(ex.getMessage());
    	}
    }
    
    @ApiOperation(value = "编辑")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public CommonResult<Object> update(@RequestBody Rank rank){
        try {
            Rank rank2 = rankService.getById(rank.getId());
        	if(rank2 == null) {
        		throw new Exception("id无效");
        	}
        	
			if (StringUtils.isBlank(rank.getValue())) {
				throw new Exception("描述不能为空");
			}

			User my = ThreadLocalUtil.get("user");
			// 确认管理员身份
			if (my.getType() != 1) {
				return CommonResult.failed("无权操作");
			}
			
            HashMap<String,Object> ret = new  HashMap<String, Object>();
            ret.put("ret", rankService.updateById(rank));
            return CommonResult.success(ret);
        }catch (Exception ex) {
            return CommonResult.failed(ex.getMessage());
        }
    }    

}
