package com.interceptor;

import com.alibaba.fastjson.JSONObject;
import com.common.CheckFrontToken;
import com.common.CommonResult;
import com.qtdszws.ipv6.util.Session;
import com.utils.RedisUtil;
import com.utils.RequestUtil;
import com.utils.ThreadLocalUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 移动端管理端 token验证拦截器 使用前注意需要一个@Bean手动注解，否则注入无效
 * +---------------------------------------------------------------------- |
 * CRMEB [ CRMEB赋能开发者，助力企业发展 ]
 * +---------------------------------------------------------------------- |
 * Copyright (c) 2016~2020 https://www.crmeb.com All rights reserved.
 * +---------------------------------------------------------------------- |
 * Licensed CRMEB并不是自由软件，未经许可不能去掉CRMEB相关版权
 * +---------------------------------------------------------------------- |
 * Author: CRMEB Team <admin@crmeb.com>
 * +----------------------------------------------------------------------
 */
public class FrontTokenInterceptor implements HandlerInterceptor {
	@Autowired
	private CheckFrontToken checkFrontToken;
	@Autowired
	protected RedisUtil redisUtil;

	// 程序处理之前需要处理的业务
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		ThreadLocalUtil.remove();

		Session.Create(request, redisUtil, true);

		// url不需要过滤
		boolean result = checkFrontToken.checkRouter(RequestUtil.getUri(request));
		if (result) {
			return true;
		}

		result = checkFrontToken.check();
		if (result) {
			return result;
		}

		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(JSONObject.toJSONString(CommonResult.unauthorized()));
		return false;
	}

	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) {

	}

	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
			Exception ex) {

		Session.save();
		ThreadLocalUtil.remove();
	}

}
