package com.common;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.constants.Constants;
import com.utils.RedisUtil;
import com.utils.RequestUtil;
import com.utils.ThreadLocalUtil;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.qtdszws.ipv6.user.User;
import com.qtdszws.ipv6.user.UserService;
import com.qtdszws.ipv6.util.Session;

/**
 * +----------------------------------------------------------------------
 * | CRMEB [ CRMEB赋能开发者，助力企业发展 ]
 * +----------------------------------------------------------------------
 * | Copyright (c) 2016~2020 https://www.crmeb.com All rights reserved.
 * +----------------------------------------------------------------------
 * | Licensed CRMEB并不是自由软件，未经许可不能去掉CRMEB相关版权
 * +----------------------------------------------------------------------
 * | Author: CRMEB Team <admin@crmeb.com>
 * +----------------------------------------------------------------------
 * 检测token是否过期
 */
@Component
public class CheckFrontToken {
    
    @Autowired
    protected UserService userService;
    
    public Boolean check(){

        try {
            	if(Session.get("userID") == null)   {             
                	return false;
                }
                
            	Integer userID = (Integer)Session.get("userID");
                User user = userService.getById(userID);
                if(user == null) {
                	return false;
                }
                HashMap<String,Object> map = new HashMap<String, Object>();
                map.put("userID", userID);
                map.put("user", user);
                //map.put("token", token); //session里会增加
                ThreadLocalUtil.set(map);
                return true;          
        }catch (Exception e){
            return false;
        }
    }

    //路由在此处，则返回true，无论用户是否登录都可以访问
    public boolean checkRouter(String uri) {
    	
        String[] routerList = {
                "api/user/",
                "api/helper/getVerifyCode",
        };
        
    	//return ArrayUtils.contains(routerList, uri);
        for(String s:routerList) {
        	if(uri.startsWith(s)) return true;
        }
        return false;
    	
        //return !uri.endsWith("/api/user/");
    	//return false;
    }

}
