//package com.zbkj.crmeb;
//
//import com.alibaba.fastjson.JSONObject;
//import com.zbkj.crmeb.sms.service.SmsService;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest
//@ContextConfiguration
//public class CrmebApplicationTests {
//
////    @Test
////    void contextLoads() {
////    }
////    @Autowired
////    private UserMapper userMapper;
////
////    @Test
////    void testSelecte(){
////        System.out.println("----------Start test----------");
////        List<User> userList = userMapper.selectList(null);
////        Assert.assertEquals(5, userList.size());
////        userList.forEach(System.out::println);
////    }
//
//    @Autowired
//    private SmsService smsService;
//
//    @Test
//    public void testIsLogin() {//是否登录
////        JSONObject login = smsService.isLogin();
////        System.out.println(login);
//    }
//
//    @Test
//    public void testSendCodeForRegister() {//注册短信
//
//    }
//
//    @Test
//    public void testLogin() {//登录
//
//    }
//
//    @Test
//    public void testInfo() {//用户信息
//
//    }
//
//    @Test
//    public void testTempList() {//短信模板列表
//
//    }
//
//    @Test
//    public void testPayList() {//支付套餐列表
//
//    }
//
//    @Test
//    public void testPayQrcode() {//支付码
//
//    }
//
//    @Test
//    public void sendCode() {//发送短信
//
//    }
//}
