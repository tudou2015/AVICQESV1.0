<template>
		<view class="u-navbar-area">
			<u-navbar title-color="#fff" back-icon-color="#ffffff" :is-fixed="isFixed"
				:is-back="isBack" :background="background" :back-text-style="{color: '#fff'}"
				:title="title" :back-icon-name="backIconName" :back-text="backText">
				<view class="slot-wrap" v-if="useSlot">
					<view class="search-wrap" v-if="search">
						<!-- 如果使用u-search组件，必须要给v-model绑定一个变量 -->
						<u-search v-model="keyword" :show-action="showAction" height="56"
							:action-style="{color: '#fff'}"></u-search>
					</view>
					<view class="navbar-right" v-if="rightSlot">
						<view class="message-box right-item">
							<u-icon name="chat" size="38"></u-icon>
							<u-badge count="18" size="mini" :offset="[-15, -15]"></u-badge>
						</view>
						<view class="dot-box right-item">
							<u-icon name="calendar-fill" size="38"></u-icon>
							<u-badge size="mini" :is-dot="true" :offset="[-6, -6]"></u-badge>
						</view>
					</view>
					<view class="map-wrap" v-if="custom">
						<u-icon name="map" color="#ffffff" size="24"></u-icon>
						<text class="map-wrap-text">test</text>
						<u-icon name="arrow-down-fill" color="#ffffff" size="22"></u-icon>
					</view>
				</view>
				<view class="navbar-right" slot="right" v-if="slotRight">
					<view class="message-box right-item">
						<u-icon name="chat" size="38"></u-icon>
						<u-badge count="18" size="mini" :offset="[-15, -15]"></u-badge>
					</view>
					<view class="dot-box right-item">
						<u-icon name="calendar-fill" size="38"></u-icon>
						<u-badge size="mini" :is-dot="true" :offset="[-6, -6]"></u-badge>
					</view>
				</view>
			</u-navbar>
		</view>
</template>

<script>
	export default {
		props:{
			title: String,			
		},
		data() {
			return {
					backText: '返回',
					backIconName: 'nav-back',
					right: false,
					showAction: false,
					rightSlot: false,
					useSlot: false,
					background: {
						//'background-image': 'linear-gradient(45deg, rgb(28, 187, 180), rgb(141, 198, 63))'
						'background-image': 'linear-gradient(45deg, rgb(0, 187, 255), rgb(0, 198, 255))'
					},
					isBack: false,
					search: false,
					custom: false,
					isFixed: true,
					keyword: '',
					// #ifdef MP
					slotRight: false,
					// #endif
					// #ifndef MP
					slotRight: false
					// #endif
				
			}
		},
		created(){
					let pages = getCurrentPages();
					//console.log(pages);
					if(pages.length>1){
						this.isBack = true;
					}else{
						this.isBack = false;
					}
				}

	}
</script>

<style>

</style>
