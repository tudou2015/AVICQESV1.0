<template>
		<view class="u-tabbar-area">
			<u-tabbar v-model="current" :show="show" :bg-color="bgColor"
				:border-top="borderTop" :list="list" :mid-button="midButton"
				:activeColor="activeColor" :inactive-color="inactiveColor"></u-tabbar>
		</view>
</template>

<script>
	export default {
		data() {
			return {
					current: 0,
					show: true,
					bgColor: '#ffffff',
					borderTop: true,
				
					list: [{
							pagePath: "/pages/index/index",
							iconPath: "/static/home.png",
							selectedIconPath: "/static/home-active.png",
							text: '首页',
							isDot: false,
							customIcon: false,
						},
						{
							pagePath: "/pages/test/index1",
							iconPath: "/static/task.png",
							selectedIconPath: "/static/task-active.png",
							text: '图片',
							customIcon: false,
						},
						{
							pagePath: "/pages/test/index2",
							iconPath: "/static/min_button.png",
							selectedIconPath: "/static/min_button_select.png",
							text: '音频',
							midButton: false,
							customIcon: false,
						},
						{
							pagePath: "/pages/test/index3",
							iconPath: "/static/top.png",
							selectedIconPath:  "/static/top-active.png",
							text: '视频',
							midButton: false,
							customIcon: false,
						},
						{
							pagePath: "/pages/center/index",
							iconPath: "/static/center.png",
							selectedIconPath: "/static/center-active.png",
							text: '管理',
							isDot: false,
							customIcon: false,
						},
					],
					midButton: false,
					inactiveColor: '#909399',
					activeColor: '#5098FF',
				
			}
		},
		/*mounted: function(){
				console.log("mounted");
				uni.onTabBarMidButtonTap(() => {
					uni.navigateTo({
						url: "/pages/task/add",
						animationType: "slide-in-bottom",
						animationDuration: 150
					})
				})
			},*/
		methods: {
			
		}
	}
</script>

<style>

</style>
