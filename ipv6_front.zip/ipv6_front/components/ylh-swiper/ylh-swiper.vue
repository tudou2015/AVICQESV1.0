<template>

			<view class="u-swiper-area">
				<u-swiper :height="250" :list="list" :title="title" :effect3d="effect3d"
					:indicator-pos="indicatorPos" :mode="mode" :interval="3000"
					@click="click"
					></u-swiper>
			</view>
	
</template>

<script>
	export default {
		name:"ylh-swiper",
		data() {
			return {
					current: 0,
					show: true,
					bgColor: '#ffffff',
					borderTop: true,
					topSwiperIndex: 0,
					list: [],
					title: "",
					mode: 'round',
					indicatorPos: 'bottomCenter',
					effect3d: false,
				
			};
		},
		mounted(){
			this.$u.api.getSwiperingSearch({
					name: '',
					page: 1,
					limit: 10
				}).then(res => {
				//console.log(res)
				let list = [];
				for(let swiper of res.list){
					list.push({
						link:swiper.imglink,
						image:swiper.imgurl,
						title:swiper.name,
						});
				}
				this.list = list;
			})
		},
		methods:{		
			click(index){
					//console.log(index)
					let swiper = this.list[index];
					//console.log(swiper)
					if(!swiper.link) return;
					let link = swiper.link.toLowerCase();
					if(!link.startsWith('http://') && !link.startsWith('https://'))
					{
						link = 'http://' + swiper.link;
					}
					location.href = link;
			}
		}
	}
</script>

<style>

</style>
