// 如果没有通过拦截器配置域名的话，可以在这里写上完整的URL(加上域名部分)
let api_prefix = '/api/';


let getTestListUrl = api_prefix + 'test/list';
let addTestUrl = api_prefix + 'test/add';
let getTestUrl = api_prefix + 'test/get';
let updateTestUrl = api_prefix + 'test/update';
let delTestUrl = api_prefix + 'test/del';

let getItemListUrl = api_prefix + 'item/list';
let addItemUrl = api_prefix + 'item/add';
let getItemUrl = api_prefix + 'item/get';
let updateItemUrl = api_prefix + 'item/update';
let delItemUrl = api_prefix + 'item/del';

let getCategoryListUrl = api_prefix + 'category/list';
let getCategoryUrl = api_prefix + 'category/get';
let updateCategoryUrl = api_prefix + 'category/update';

let getRankListUrl = api_prefix + 'rank/list';
let getRankUrl = api_prefix + 'rank/get';
let updateRankUrl = api_prefix + 'rank/update';

let getScoreListUrl = api_prefix + 'score/list';
let saveScoresUrl = api_prefix + 'score/save';

let getUserListUrl = api_prefix + 'user/list';
let getUserUrl = api_prefix + 'user/get';
let updateUserUrl = api_prefix + 'user/update';
let checkTokenUrl = api_prefix + 'user/checkToken';
let regUserUrl = api_prefix + 'user/reg';
let loginUrl = api_prefix + 'user/login';

let getVerifycodeUrl = api_prefix + 'helper/getVerifyCode';

// 此处第二个参数vm，就是我们在页面使用的this，你可以通过vm获取vuex等操作，更多内容详见uView对拦截器的介绍部分：
// https://uviewui.com/js/http.html#%E4%BD%95%E8%B0%93%E8%AF%B7%E6%B1%82%E6%8B%A6%E6%88%AA%EF%BC%9F
const install = (Vue, vm) => {
	// 此处没有使用传入的params参数
	
	let getTestList = (params = {}) => vm.$u.get(getTestListUrl, params);	
	let addTest = (params = {}) => vm.$u.post(addTestUrl, params);	
	let getTest = (params = {}) => vm.$u.get(getTestUrl, params);	
	let updateTest = (params = {}) => vm.$u.post(updateTestUrl, params);	
	let delTest = (params = {}) => vm.$u.get(delTestUrl, params);	
	
	let getItemList = (params = {}) => vm.$u.get(getItemListUrl, params);
	let addItem = (params = {}) => vm.$u.post(addItemUrl, params);	
	let getItem = (params = {}) => vm.$u.get(getItemUrl, params);	
	let updateItem = (params = {}) => vm.$u.post(updateItemUrl, params);	
	let delItem = (params = {}) => vm.$u.get(delItemUrl, params);	

	let getCategoryList = (params = {}) => vm.$u.get(getCategoryListUrl, params);
	let getCategory = (params = {}) => vm.$u.get(getCategoryUrl, params);	
	let updateCategory = (params = {}) => vm.$u.post(updateCategoryUrl, params);	

	let getRankList = (params = {}) => vm.$u.get(getRankListUrl, params);
	let getRank = (params = {}) => vm.$u.get(getRankUrl, params);	
	let updateRank = (params = {}) => vm.$u.post(updateRankUrl, params);	

	let getScoreList = (params = {}) => vm.$u.get(getScoreListUrl, params);
	let saveScores = (params = {}) => vm.$u.post(saveScoresUrl, params);	
		
	let getUserList = (params = {}) => vm.$u.get(getUserListUrl, params);
	let getUser = (params = {}) => vm.$u.get(getUserUrl, params);
	let updateUser = (params = {}) => vm.$u.post(updateUserUrl, params);
	let login = (params = {}) => vm.$u.post(loginUrl, params);
	let checkToken = (params = {}) => vm.$u.post(checkTokenUrl, params);
	let regUser = (params = {}) => vm.$u.post(regUserUrl, params);

	let getVerifycode = (params = {}) => vm.$u.get(getVerifycodeUrl, params);

	// 此处使用了传入的params参数，一切自定义即可
	//let getInfo = (params = {}) => vm.$u.post(indexUrl, params);

	// 将各个定义的接口名称，统一放进对象挂载到vm.$u.api(因为vm就是this，也即this.$u.api)下
	vm.$u.api = {
		getTestList,
		addTest,
		getTest,
		updateTest,
		delTest,
		
		
		getItemList,
		addItem,
		getItem,
		updateItem,
		delItem,

		getCategoryList,
		getCategory,
		updateCategory,

		getRankList,
		getRank,
		updateRank,

		getScoreList,
		saveScores,
			
		getUserList,
		getUser,
		updateUser, 
		login,
		checkToken,
		regUser,

		getVerifycode,
	};
}

export default {
	install
}

