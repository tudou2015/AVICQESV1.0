<template>
	<view class="content">
		<ylh-navbar :title="title"></ylh-navbar>

		<view></view>
		
		<ylh-tabbar></ylh-tabbar>
	</view>
</template>

<script>
	export default {
		data() {
			return {

				title: "IPv6",
			}
		},
		onShow() {
			this.checkToken();
		},
		methods: {		
			
			checkToken(){
				// console.log('onShow');
				this.$u.api.checkToken().then(res => {
					if (res.ret) {
						this.user = res.user;
					}else{
						uni.showModal({
							title: "需要登录",
							content: res.message,
							showCancel:false,
							success(res) {
								if (res.confirm) {
									uni.navigateTo({
										url: '/pages/login/index'
									})
								}
							}
						});
						
					}
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	page {
		background-color: #ededed;
	}

	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		//padding: 40rpx;
	}

	
</style>
