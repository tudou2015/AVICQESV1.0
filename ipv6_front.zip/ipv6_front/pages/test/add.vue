<template>
	<view class="content">
		<ylh-navbar :title="title"></ylh-navbar>

		<u-form class="add_form">
			<u-form-item   label="类型" label-width="150">
				<u-radio-group v-model="data.type">
					<u-radio shape="circle" v-for="(t, index) in typeMap" :key="index" :name="t.value">{{ t.label }}</u-radio>
				</u-radio-group>
			</u-form-item>			
			
			<u-form-item label-width="130" label="标题">
				<u-input type="text" v-model="data.title" />
			</u-form-item>

			<u-form-item label-width="130" label="描述">
				<u-input type="textarea" v-model="data.content" />
			</u-form-item>

			<u-button class="bottom-button" type="primary" size="default" @click="submit">添加</u-button>
		</u-form>

		<ylh-tabbar></ylh-tabbar>
	</view>
</template>

<script>

	export default {
		data() {
			return {
				title: "添加测试",
				typeMap: [{
						value: '1',
						label: '图片'
					},
					{
						value: '2',
						label: '音频'
					},
					{
						value: '3',
						label: '视频'
					}
				],
				data: {
					type: 0,
					title: '',
					content: '',
				},
			}
		},
		
		onShow() {
		},
		methods: {
			submit() {
				this.$u.api.addTest(this.data).then(res => {
					if (res && res.ret) {					
						uni.showModal({
							title:"消息",
							content: "添加成功",
							showCancel:false,
							success(res){
								uni.navigateBack()
							}
						})
					}
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.add_form {
		padding: 0rpx 30rpx;
		width: 100%;
	}

	.custom-style {
		margin-left: unset;
	}


	/*    .u-form-item--left{ 
		flex:0 0 140rpx !important; 
	}*/
	
	.bangzhu{
		position: fixed;
		_position:absolute;
		right: 5px;
		bottom: 120px;
		word-break:break-all;
	}	
	.bottom-button {
		margin-top: 20rpx;
		margin-bottom: 20rpx;
	}
</style>
