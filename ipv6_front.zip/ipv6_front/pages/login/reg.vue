<template>
	<view class="content">
		<ylh-navbar :title="title"></ylh-navbar>

		<u-form :model="model" class="reg_form" :rules="rules" ref="uForm" :errorType="errorType">
			<u-form-item :rightIconStyle="{color: '#888', fontSize: '32rpx'}" 
				:label-position="labelPosition" label="用户名" prop="name" label-width="150">
				<u-input :border="border" placeholder="请输入用户名" v-model="model.name" type="text"></u-input>
			</u-form-item>
			<u-form-item :label-position="labelPosition" label="密码" prop="passwd" label-width="150">
				<u-input :password-icon="true" :border="border" type="password" v-model="model.passwd"
					placeholder="请输入密码"></u-input>
			</u-form-item>
			<u-form-item :label-position="labelPosition" label="确认密码" label-width="150" prop="rePasswd">
				<u-input :border="border" type="password" v-model="model.rePasswd" placeholder="请确认密码"></u-input>
			</u-form-item>
			<u-form-item :label-position="labelPosition" label="验证码" prop="code" label-width="150">
				<u-input placeholder="请输入验证码" v-model="model.code" type="text"></u-input>
				<u-image :src="codeImg" width="60px"  height="30px"  mode="scaleToFill"  @click="reloadCode"></u-image>
			</u-form-item>			
			<u-button type="primary" size="default" @click="submit">注册</u-button>
		</u-form>
		<u-verification-code seconds="10" ref="uCode" @change="codeChange"></u-verification-code>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: '注册',
				src: '/static/banner.png',
				codeImg:'',
				model: {
					name: '',
					passwd: '',
					rePasswd: '',
					code: '',
				},
				border: false,
				codeTips: '',
				rules: {
					name: [{
							required: true,
							message: '请输入用户名',
							trigger: ['change', 'blur'],
						},
					],
					passwd: [{
							required: true,
							message: '请输入密码',
							trigger: ['change', 'blur'],
						},
						{
							// 正则不能含有两边的引号
							pattern: /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]+\S{5,12}$/,
							message: '需同时含有字母和数字，长度在6-12之间',
							trigger: ['change', 'blur'],
						}
					],
					rePasswd: [{
							required: true,
							message: '请重新输入密码',
							trigger: ['change', 'blur'],
						},
						{
							validator: (rule, value, callback) => {
								return value === this.model.passwd;
							},
							message: '两次输入的密码不相等',
							trigger: ['change', 'blur'],
						}
					],
					code: [{
							required: true,
							message: '请输入验证码',
							trigger: ['change', 'blur'],
						},
						{
							// 正则不能含有两边的引号
							//pattern: /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]+\S{1,12}$/,
							min: 4,
							max: 4,
							message: '密码长度4个字符',
							trigger: ['change', 'blur'],
						}
					],
				},
				errorType: ['message'],
				labelPosition: 'left',
			}
		},
		onShow(){
			this.reloadCode();
		},
		methods: {
			reloadCode(){
				this.$u.api.getVerifycode().then(res=>{
					if(res.ret){
						this.codeImg =  res.img;
						uni.setStorageSync('token', res.token);						
					}
				});
			},
			submit() {
				let that = this;
				that.$refs.uForm.validate(valid => {
					if (valid) {
						// console.log(that.model);
						that.$u.api.regUser(that.model).then(res => {
							// console.log(res);
							if (res.ret) {
								uni.showToast({
									title: "注册成功",
									icon: 'success'
								});
								setTimeout(() => {
									uni.redirectTo({
										url: '/pages/login/index'
									})
								}, 3000);
							}
						});
					} else {
						console.log('验证失败');
					}
				});



			},
			codeChange(text) {
				this.codeTips = text;
			},
			// 获取验证码
			getCode() {
				if (this.$refs.uCode.canGetCode) {
					// 模拟向后端请求验证码
					if (!this.$u.test.mobile(this.model.phone)) {
						alert("请先输入手机号");
						return;
					}
					uni.showLoading({
						title: '正在获取验证码',
						mask: true
					});

					this.$u.api.getSmsCode({
						phone: this.model.phone
					}).then(res => {
						if (res.ret) {
							uni.setStorageSync('token', res.token);
							alert("您的验证码是" + res.code);
						}
					}).catch(res => {
							uni.showToast({
								title: res.message,
								icon: 'none'
							});
						});

					setTimeout(() => {
						uni.hideLoading();
						// 这里此提示会被this.start()方法中的提示覆盖
						this.$u.toast('验证码已发送');
						// 通知验证码组件内部开始倒计时
						this.$refs.uCode.start();
					}, 2000);
				} else {
					this.$u.toast('倒计时结束后再发送');
				}
			},
			errorChange(index) {
				if (index == 0) this.errorType = ['message'];
				if (index == 1) this.errorType = ['toast'];
				if (index == 2) this.errorType = ['border-bottom'];
				if (index == 3) this.errorType = ['border'];
			}

		},
		onReady() {
			this.$refs.uForm.setRules(this.rules);
		}
	}
</script>

<style lang="scss" scoped>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.reg_form {
		padding: 0rpx 3rpx;
		width: 100%;
	}
</style>
