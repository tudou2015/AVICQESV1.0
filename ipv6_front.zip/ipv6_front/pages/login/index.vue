<template>
	<view class="content">
		<view class="banner">
			<u-image mode="widthFix" :src="src"></u-image>
		</view>

		<u-form :model="model" class="login_form" :rules="rules" ref="uForm" :errorType="errorType">
			<u-form-item label-width="150" :leftIconStyle="{color: '#888', fontSize: '32rpx'}" left-icon="phone"
				:label-position="labelPosition" label="用户名" prop="name">
				<u-input placeholder="请输入用户名" v-model="model.name" type="text"></u-input>
			</u-form-item>
			<u-form-item label-width="150" :label-position="labelPosition" left-icon="lock" label="密码" prop="passwd">
				<u-input :password-icon="true" type="password" v-model="model.passwd" placeholder="请输入密码"></u-input>
			</u-form-item>
			<u-form-item :label-position="labelPosition" label="验证码" prop="code" label-width="150">
				<u-input placeholder="请输入验证码" v-model="model.code" type="text"></u-input>
				<u-image :src="codeImg" width="60px"  height="30px"  mode="scaleToFill"  @click="reloadCode"></u-image>
			</u-form-item>			
			<u-button type="primary" size="default" @click="submit">登录</u-button>
		</u-form>

		<u-button :plain="true" type="primary" size="medium" @click="reg">还没有账户？立即注册</u-button>

		<view class="ver-area">
			版本信息： V1.0
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				src: '/static/login_banner.png',
				codeImg:'',
				model: {
					name: '',
					passwd: '',
					code: '',
				},
				rules: {
					name: [{
							required: true,
							message: '请输入用户名',
							trigger: ['change', 'blur'],
						}						
					],
					password: [{
							required: true,
							message: '请输入密码',
							trigger: ['change', 'blur'],
						},
						{
							// 正则不能含有两边的引号
							//pattern: /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]+\S{1,12}$/,
							min: 3,
							max: 8,
							message: '密码长度在3到8个字符',
							trigger: ['change', 'blur'],
						}
					],
					code: [{
							required: true,
							message: '请输入验证码',
							trigger: ['change', 'blur'],
						},
						{
							// 正则不能含有两边的引号
							//pattern: /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]+\S{1,12}$/,
							min: 4,
							max: 4,
							message: '密码长度4个字符',
							trigger: ['change', 'blur'],
						}
					],
				},
				errorType: ['message'],
				labelPosition: 'left',
			}
		},
		onShow(){
			this.reloadCode();
		},
		methods: {	
			reloadCode(){
				this.$u.api.getVerifycode().then(res=>{
					if(res.ret){
						this.codeImg =  res.img;
						uni.setStorageSync('token', res.token);						
					}
				});
			},
			submit() {
				let that = this;
				that.$refs.uForm.validate(valid => {
					if (valid) {
						//console.log(that.model);
						that.$u.api.login(that.model).then(res => {
							// console.log(res);
							if (res.ret) {
								uni.setStorageSync('token', res.token);
								uni.setStorageSync('userID', res.userID);
									let pages = getCurrentPages();
									if (pages.length > 1) {
										uni.navigateBack();
									} else {
										uni.reLaunch({
											url: '/pages/index/index'
										})
									}								
							}
						});

					} else {
						console.log('验证失败');
					}
				});

			},
			reg() {
				uni.redirectTo({
					url: '/pages/login/reg'
				})
			}

		},
		onReady() {
			this.$refs.uForm.setRules(this.rules);
		}
	}
</script>

<style lang="scss" scoped>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		padding-top: 100rpx;
	}

	.banner {
		padding: 0rpx 50rpx;
		width: 100%;
	}

	.login_form {
		padding: 80rpx 30rpx;
		width: 100%;
	}

	.ver-area {
		padding: 100rpx 30rpx;
	}
</style>
